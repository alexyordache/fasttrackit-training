package org.fasttrackit.universitynotification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityNotificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
