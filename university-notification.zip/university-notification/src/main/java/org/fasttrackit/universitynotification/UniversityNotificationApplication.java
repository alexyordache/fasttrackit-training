package org.fasttrackit.universitynotification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityNotificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityNotificationApplication.class, args);
	}

}
